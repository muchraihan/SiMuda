<?php

return [
    'reset' => 'Kata sandi Anda telah diperbarui.',
    'sent' => 'Kami telah mengirimkan tautan reset kata sandi ke email Anda.',
    'throttled' => 'Silakan tunggu sebelum mencoba lagi.',
    'token' => 'Token reset kata sandi ini tidak valid.',
    'user' => 'Kami tidak dapat menemukan pengguna dengan alamat email tersebut.',
];
